import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const BilOuFassApp());

const Color forest = Color(0xFF063D30);
const Color deepForest = Color(0xFF032820);
const Color gold = Color(0xFFF2C66D);
const Color cream = Color(0xFFFFF5D9);

class BilOuFassApp extends StatelessWidget {
  const BilOuFassApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بيل أو فاص',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: deepForest,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        fontFamily: 'Roboto',
      ),
      home: const GameScreen(),
    );
  }
}

class RoundRecord {
  final String choice;
  final String result;
  final bool won;
  final int change;
  RoundRecord(this.choice, this.result, this.won, this.change);
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});
  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin {
  int balance = 1000;
  int wins = 0;
  int played = 0;
  String selected = 'الوجه';
  String coinSide = 'الوجه';
  bool flipping = false;
  bool soundOn = true;
  String status = 'اختار الوجه أو الكتابة، ومن بعد رمي العملة';
  final List<RoundRecord> history = [];
  late final AnimationController _controller;
  late final Animation<double> _rotation;
  SharedPreferences? prefs;
  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));
    _rotation = Tween<double>(begin: 0, end: 8 * pi).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      prefs = p;
      balance = p.getInt('balance') ?? 1000;
      wins = p.getInt('wins') ?? 0;
      played = p.getInt('played') ?? 0;
    });
  }

  Future<void> _save() async {
    final p = prefs ?? await SharedPreferences.getInstance();
    prefs = p;
    await p.setInt('balance', balance);
    await p.setInt('wins', wins);
    await p.setInt('played', played);
  }

  Future<void> _flip() async {
    if (flipping) return;
    if (balance < 10) {
      setState(() => status = 'الرصيد ما كافيش. استرجع 100 نقطة مجانية للتجربة.');
      return;
    }
    setState(() {
      flipping = true;
      status = 'العملة كتدور...';
      balance -= 10;
    });
    await _save();
    await _controller.forward(from: 0);
    final result = _random.nextBool() ? 'الوجه' : 'الكتابة';
    final won = result == selected;
    setState(() {
      coinSide = result;
      played++;
      if (won) {
        wins++;
        balance += 20; // 10 stake returned plus 10 net reward
        status = 'ربحتي! +10 نقاط صافية 🎉';
      } else {
        status = 'هاد المرة ما صابتش. جرّب مرة أخرى!';
      }
      history.insert(0, RoundRecord(selected, result, won, won ? 10 : -10));
      if (history.length > 8) history.removeLast();
      flipping = false;
    });
    await _save();
  }

  Future<void> _claimFreePoints() async {
    setState(() {
      balance += 100;
      status = 'زدناك 100 نقطة مجانية للتجربة!';
    });
    await _save();
  }

  Future<void> _reset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إعادة ضبط اللعبة؟'),
        content: const Text('غادي يرجع الرصيد لـ 1000 نقطة ويتصفّر التقدم.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إعادة الضبط')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() {
      balance = 1000;
      wins = 0;
      played = 0;
      history.clear();
      coinSide = 'الوجه';
      status = 'رجعنا البداية. بالتوفيق!';
    });
    final p = prefs ?? await SharedPreferences.getInstance();
    await p.clear();
    prefs = p;
    await _save();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rate = played == 0 ? 0 : (wins * 100 / played).round();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: deepForest,
          title: const Row(
            children: [
              Icon(Icons.stars_rounded, color: gold, size: 29),
              SizedBox(width: 8),
              Text('بيل أو فاص', style: TextStyle(fontWeight: FontWeight.bold, color: cream)),
            ],
          ),
          actions: [
            IconButton(
              tooltip: soundOn ? 'إيقاف الصوت' : 'تشغيل الصوت',
              onPressed: () => setState(() => soundOn = !soundOn),
              icon: Icon(soundOn ? Icons.volume_up_rounded : Icons.volume_off_rounded, color: gold),
            ),
            IconButton(tooltip: 'إعادة ضبط', onPressed: _reset, icon: const Icon(Icons.restart_alt, color: cream)),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF0E6349), forest]),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: gold.withOpacity(.5)),
                ),
                child: Column(
                  children: [
                    const Text('رصيدك الحالي', style: TextStyle(color: cream, fontSize: 14)),
                    const SizedBox(height: 5),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.monetization_on_rounded, color: gold, size: 34),
                        const SizedBox(width: 8),
                        Text('$balance', style: const TextStyle(color: gold, fontSize: 36, fontWeight: FontWeight.w900)),
                        const SizedBox(width: 6),
                        const Text('نقطة', style: TextStyle(color: cream, fontSize: 15)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _miniStat('الجولات', '$played', Icons.casino_outlined),
                        const SizedBox(width: 8),
                        _miniStat('الانتصارات', '$wins', Icons.emoji_events_outlined),
                        const SizedBox(width: 8),
                        _miniStat('نسبة الفوز', '$rate%', Icons.trending_up_rounded),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text('اختار وجه العملة', textAlign: TextAlign.center,
                style: TextStyle(color: cream, fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              const Text('تكلفة الجولة 10 نقاط • الفوز يربحك 10 نقاط صافية',
                textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFB9CFC5), fontSize: 12)),
              const SizedBox(height: 18),
              AnimatedBuilder(
                animation: _rotation,
                builder: (context, child) {
                  final angle = flipping ? _rotation.value : 0.0;
                  final turn = angle % (2 * pi);
                  final scaleX = (cos(turn)).abs().clamp(.18, 1.0);
                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()..scale(scaleX, 1.0),
                    child: child,
                  );
                },
                child: Center(
                  child: Container(
                    width: 174, height: 174,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const RadialGradient(colors: [Color(0xFFFFE9A2), Color(0xFFD69A2D), Color(0xFF8B5817)]),
                      boxShadow: [BoxShadow(color: gold.withOpacity(.25), blurRadius: 26, spreadRadius: 2)],
                      border: Border.all(color: const Color(0xFFFFE6A0), width: 4),
                    ),
                    padding: const EdgeInsets.all(9),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: coinSide == 'الوجه' ? const Color(0xFFB92B25) : const Color(0xFF0D5A40),
                        border: Border.all(color: const Color(0xFFFFE6A0), width: 2),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (coinSide == 'الوجه')
                            const Text('★', style: TextStyle(fontSize: 68, color: Color(0xFF0A6A3D), height: 1))
                          else
                            const Icon(Icons.auto_awesome, size: 58, color: gold),
                          Text(coinSide, style: const TextStyle(color: cream, fontSize: 19, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(child: _choiceButton('الوجه', Icons.stars_rounded)),
                  const SizedBox(width: 12),
                  Expanded(child: _choiceButton('الكتابة', Icons.auto_awesome_rounded)),
                ],
              ),
              const SizedBox(height: 14),
              SizedBox(
                height: 56,
                child: FilledButton.icon(
                  onPressed: flipping ? null : _flip,
                  icon: const Icon(Icons.casino_rounded),
                  label: Text(flipping ? 'العملة كتدور...' : 'رمي العملة • 10 نقاط',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  style: FilledButton.styleFrom(
                    backgroundColor: gold, foregroundColor: deepForest,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFF0D382D), borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: gold.withOpacity(.24))),
                child: Text(status, textAlign: TextAlign.center,
                  style: const TextStyle(color: cream, fontSize: 15, fontWeight: FontWeight.w600)),
              ),
              if (balance < 10) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(onPressed: _claimFreePoints, icon: const Icon(Icons.card_giftcard),
                  label: const Text('الحصول على 100 نقطة مجانية'),
                  style: OutlinedButton.styleFrom(foregroundColor: gold, side: const BorderSide(color: gold))),
              ],
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('آخر الجولات', style: TextStyle(color: cream, fontSize: 19, fontWeight: FontWeight.bold)),
                  TextButton(onPressed: () => setState(() => history.clear()), child: const Text('مسح السجل')),
                ],
              ),
              if (history.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(18),
                  child: Text('مازال ما لعبتي حتى جولة فهاد الجلسة.', textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF9EB7AC))),
                )
              else
                ...history.map((r) => Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(color: const Color(0xFF0B3329), borderRadius: BorderRadius.circular(13)),
                  child: Row(
                    children: [
                      Icon(r.won ? Icons.check_circle_rounded : Icons.cancel_rounded,
                        color: r.won ? const Color(0xFF67D7A1) : const Color(0xFFFF8B80)),
                      const SizedBox(width: 10),
                      Expanded(child: Text('اختيارك: ${r.choice} • النتيجة: ${r.result}',
                        style: const TextStyle(color: cream, fontSize: 12))),
                      Text('${r.change > 0 ? '+' : ''}${r.change}',
                        style: TextStyle(color: r.won ? const Color(0xFF67D7A1) : const Color(0xFFFF8B80),
                          fontWeight: FontWeight.bold)),
                    ],
                  ),
                )),
              const SizedBox(height: 10),
              const Text('لعبة ترفيهية بنقاط افتراضية فقط. لا توجد أموال حقيقية أو قيمة نقدية للنقاط.',
                textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF8CA79B), fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniStat(String title, String value, IconData icon) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
      decoration: BoxDecoration(color: Colors.black.withOpacity(.12), borderRadius: BorderRadius.circular(13)),
      child: Column(children: [
        Icon(icon, color: gold, size: 18),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(color: cream, fontSize: 16, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(color: Color(0xFFC5D7CF), fontSize: 10)),
      ]),
    ),
  );

  Widget _choiceButton(String value, IconData icon) {
    final active = selected == value;
    return OutlinedButton(
      onPressed: flipping ? null : () => setState(() => selected = value),
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 15),
        backgroundColor: active ? const Color(0xFF185D45) : const Color(0xFF092F25),
        foregroundColor: active ? gold : cream,
        side: BorderSide(color: active ? gold : const Color(0xFF315B4B), width: active ? 2 : 1),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 20), const SizedBox(width: 7),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
      ]),
    );
  }
}
